using System;

public sealed class RunEventBus : IDisposable
{
    public void Dispose() { }
}
