using System;

public sealed class AppServicesRoot : IDisposable
{
    public void Initialize() { }
    public void Dispose() { }
}
